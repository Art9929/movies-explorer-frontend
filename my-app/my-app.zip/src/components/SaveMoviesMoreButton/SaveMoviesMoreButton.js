import "./SaveMoviesMoreButton.css";

function MoviesMoreButton() {
  return (
    <section className="save-movies-more-button">
    </section>
  );
}

export default MoviesMoreButton;
